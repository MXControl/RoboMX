iceAnnounce v1.0 Plugin vor RoboMX
+++++++++++++++++++++++++++++++++++

Requirments:
++++++++++++

iceCast 2.x for Windows Server
RoboMX new then 0.2.1a
Windows 98 + IE 5.5 or newer


Installation:
+++++++++++++

Put the iceAnnounce.rEx in your RoboMX\Add-Ons 
folder and restart RoboMX. 
To configure the plugin go to the RoboMX Options
dialog (View->Options) select the Extensions tab
and doubleclick on the iceAnnounce.rEx entry in
the Extensions list.

Note:
+++++

The plugin connects to your iceCast Statistics page.
It only works with the default icecast page, and not
with any modified versions. A stats page that does 
work with this plugin is included with this zip file

License:
++++++++
iceAnnounce is released with sourcecode into public
domain. You may do what you want with both binary
and the sourcecode. 
The plugin is provided 'AS-IS' without any warranty...

