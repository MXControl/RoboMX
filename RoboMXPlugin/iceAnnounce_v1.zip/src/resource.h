//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by RoboMXPlugin.rc
//
#define IDD_CONFIG                      3000
#define IDB_ICECAST                     3001
#define IDC_STATS                       3001
#define IDC_URL                         3002
#define IDC_ANNOUNCE                    3003
#define IDC_EDIT4                       3004
#define IDC_START                       3004
#define IDC_STOP                        3005

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        3002
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         3006
#define _APS_NEXT_SYMED_VALUE           3000
#endif
#endif
